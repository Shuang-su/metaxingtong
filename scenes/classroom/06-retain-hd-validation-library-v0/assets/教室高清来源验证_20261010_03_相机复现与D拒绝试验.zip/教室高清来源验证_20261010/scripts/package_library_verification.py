from pathlib import Path
import zipfile,json,hashlib,ast
p=Path('classroom_hd_alignment_20261010');out=p/'library_delivery';out.mkdir(exist_ok=True);names=['classroom_0919_front','classroom_2123_key','classroom_4284_wide','classroom_5447_key','classroom_motion_4282']
common=[p/'复现说明.txt',p/'高清验证说明.md',p/'逐图残差.csv']
a=common+[p/'source/capture_manifest.json']+[p/'source'/f'{n}_video.png' for n in names]+[p/'renders'/f'{n}.png' for n in names]
b=common+[p/'overlays'/f'{n}_50percent.png' for n in names]+[p/'五张高清补帧_直接叠图总览.jpg',p/'D数量冲突_来源与投影ID.jpg',p/'qa/overlay_provenance.json']+list((p/'qa').glob('*_anchors.png'))
c=common+list((p/'qa').glob('*.json'))+list((p/'scripts').glob('*.py'))+[f for f in (p/'rejected_shift').rglob('*') if f.is_file() and f.suffix in ['.png','.jpg','.json']]+list((p/'old_evidence').rglob('*.json'))+[p/'阶段结果.json']
base='教室高清来源验证_20261010';manifest=[]
for idx,(label,files) in enumerate([('01_五源与原始渲染',a),('02_直接叠图与残差报告',b),('03_相机复现与D拒绝试验',c)],1):
 file=out/f'{base}_{label}.zip';unique=sorted(set(files));hashes={str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in unique}
 with zipfile.ZipFile(file,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for f in unique:z.write(f,base+'/'+str(f.relative_to(p)))
  z.writestr(base+f'/分包{idx:02}_SHA256.json',json.dumps(hashes,ensure_ascii=False,indent=2))
 with zipfile.ZipFile(file) as z:assert z.testzip() is None
 assert file.stat().st_size<18_000_000
 manifest.append({'local_path':str(file.resolve()),'filename':file.name,'bytes':file.stat().st_size,'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'library_artifact_type':'other','contains_models':False})
for f in [p/'主视角_正常材质_广角.png',p/'主视角_正常材质_D斜角.png']:
 assert f.stat().st_size<18_000_000;manifest.append({'local_path':str(f.resolve()),'filename':f.name,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'library_artifact_type':'image'})
(out/'upload_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));(out/'upload_request.json').write_text(json.dumps({'uploads':[{'local_path':v['local_path'],'purpose':'create_library_file','library_artifact_type':v['library_artifact_type']} for v in manifest]},ensure_ascii=False,indent=2));print(json.dumps(manifest,ensure_ascii=False,indent=2))
# Validate portable embedded Blender worker syntax as well as wrapper.
src=(p/'scripts/reproduce_validation.py').read_text();tree=ast.parse(src)
for node in tree.body:
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='worker' for t in node.targets):compile(ast.literal_eval(node.value),'portable_blender_worker','exec')
